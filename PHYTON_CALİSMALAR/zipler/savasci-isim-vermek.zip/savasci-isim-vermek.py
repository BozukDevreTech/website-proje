# Copyright (c) 2026 bozuk_devre
# All rights reserved.
# Developed as part of Data Structures coursework at Yaşar Üniversitesi with instructor guidance.
# This code may not be copied, modified, or distributed without explicit permission from the author.

# Bir stringin içine önceden tanımlanan bir veri veya değişken yerleştirebiliriz. Bu 
# işleme formatlama denir. Bu işlem için süslü parantez kullanmalıyız.
# Bu bilgiden yola çıkarak kullanıcıdan bir kart oluşturmasını isteyeceğim oluşturulan kart bir oyun karakterine ait olsun

alfabe = "abcçdefgğhıijklmnoöprsştuüvyzABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ "
#önceden hazırladığım karakterimi ascıı arta çevirdim çok tatlış bir şövalyem oldu.
sovalye = r"""
                 __     ___
                   *..**_  /
                  _______|/______
                 /   ____________\
                 |  |  |  ||  |  |
               **|  |  |, || ,|  |
             ****|*  \    ||    /*
            *****/ *  \________/* \
           *****(  )* _________ *  )
            *****\ \ /..       \ |/
           ***   |\,,)||++===========>
         ***     | .           . |
        *        |/ \.\.   ././ \|
                 |   \.\___/./   |
                 |     |   |     |
                 \____ ))   \_____))
"""
print(sovalye)

while True:
    isim = input("Bu karaktere bir isim ver:")

    hatali = False#hatalı olduğu durum için hatali değişkenini oluşturdum

    for harf in isim:#harf ismin içinde gezerken
        if harf not in alfabe:#harf değişkeni alfabede yoksa
            hatali = True#hatalı olsun

    if hatali == True:#eğer hatalı doğru ise bunu yazdır
        print("Lütfen sadece türkçe karakter kullan.")
        continue#kod başa döner ve kullanıcı yeni bir isim verir

    else:#eğer hatali değilse
        print("Savaşçımız {} çok yaşa!!!".format(isim))#ekrana bunu yazdır
        input()#terminal kapanmasın diye break yerine input() koydum