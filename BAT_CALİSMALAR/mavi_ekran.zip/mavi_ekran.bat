@echo off
title mavi_ekran
color 1f
cls
echo.
echo.
echo.
echo.
echo 		%date%
echo.
echo.
echo			:(
echo.
echo.

echo 	A problem has been identified, and a fun screen has been prepared to prevent your computer from getting bored.
echo.

echo 	The problem seems to be caused by the following file: "BORING.sys"
echo.

echo 	PAGE_FAULT_IN_NONPAGED_AREA
echo 	MEMORY_MANAGEMENT
echo 	SYSTEM_SERVICE_EXCEPTION
echo.

echo 	If this is the first time you've seen this error, open the file again and fun.
echo.

echo 	If the problem persists, disable the software in your brain.
echo.

echo 	Technical information:
echo.

:: Random hex üretme
set /a num1=%random% * %random%
set /a num2=%random% * %random%
set /a num3=%random% * %random%
set /a num4=%random% * %random%

echo 	*** ERROR: 0x00000033 (0x%num1%,0x%num2%,0x%num3%,0x%num4%)
echo.

echo 	BORING.sys - Address %num1% base at %num2%, DateStamp %num3%

pause >nul