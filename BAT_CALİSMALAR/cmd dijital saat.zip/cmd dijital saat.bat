@echo off
color a

:basla
echo 		------------
echo 		 %time%
echo 		------------
timeout 1 >nul
cls
goto basla